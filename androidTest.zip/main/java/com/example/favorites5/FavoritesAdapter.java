package com.example.favorites5;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.favorites5.databinding.RowFavoriteBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class FavoritesAdapter extends RecyclerView.Adapter<FavoritesAdapter.FavoritesHolder> {

    private Context context;
    private ArrayList<ModelMovie> movieArrayList;

    //Create Binding for row_favorite.xml

    private RowFavoriteBinding binding;
    private static final String TAG = "FAV_MOVIE_TAG";

    public FavoritesAdapter(Context context, ArrayList<ModelMovie> movieArrayList) {
        this.context = context;
        this.movieArrayList = movieArrayList;
    }

    @NonNull
    @Override
    //bind/inflate row_favorite.xml layout
    public FavoritesHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        binding = RowFavoriteBinding.inflate(LayoutInflater.from(context), parent, false);
        return new FavoritesHolder(binding.getRoot());
    }

    @Override
    public void onBindViewHolder(@NonNull FavoritesHolder holder, int position) {
        /*-- get/set data, handle click--*/

        ModelMovie model = movieArrayList.get(position);

        //handle click, open movie details
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        //handle click, remove from favorite list
        holder.favoriteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

    }

    private void getMovieDetails(ModelMovie model, FavoritesHolder holder){
        String movieId = model.getId();
        Log.d(TAG, "getMovieDetails:Movie Details of Movie ID"+movieId);

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference(path "Movies");
        ref.child(movieId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //get movie info

                        String movieTitle = ""+snapshot.child("title").getValue();
                        String moviePlot = ""+snapshot.child("overview").getValue();
                        String movieRating = ""+snapshot.child("vote_average").getValue();

                        //set to model
                        model.setFavorite(true);
                        model.setTitle(movieTitle);
                        model.setPlot(moviePlot);
                        model.setRating(movieRating);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    @Override
    public int getItemCount() {
        return movieArrayList.size();
    }


    //ViewHolder Class
    class FavoritesHolder extends RecyclerView.ViewHolder{

        //init ui views of row_favorite.xml
        TextView movie_title;
        ImageButton favoriteButton;
        TextView plot;
        TextView rating;

        public FavoritesHolder(@NonNull View itemView) {
            super(itemView);

            movie_title = binding.movieTitle;
            favoriteButton = binding.favoriteButton;
            plot = binding.plot;
            rating = binding.rating;
        }
    }
}

