package com.example.favorites5;

public class ModelMovie {

    String uid, id, title, plot, rating, url;
    boolean favorite;

    public ModelMovie(){

    }

    public ModelMovie(String title, String plot, String rating, boolean favorite) {
        this.title = title;
        this.plot = plot;
        this.rating = rating;
        this.favorite = favorite;
    }

    //public String getUid(){return uid;}
    //public void setUid(String uid){this.uid=uid;}

    //public String getId(){return id;}
    //public void setId(String id){this.id=id;}

    public String getTitle(){return title;}
    public void setTitle(String title){this.title=title;}

    public String getPlot(){return plot;}
    public void setPlot(String plot){this.plot=plot;}

    public String getRating(){return rating;}
    public void setRating(String rating){this.rating=rating;}

    public boolean isFavorite() {return favorite; }
    public void setFavorite(boolean favorite) { this.favorite = favorite; }
//public String getUrl(){return url;}
    //public void setUrl(String url){this.url=url;}
}

